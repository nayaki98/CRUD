package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDAO extends CrudRepository<Student, Integer>{
	
	public Student findByName(String name);
 
	@Query("Select s from Student s where s.mark= :mark")
	public List<Student> findallname(@Param("mark") String mark);
	
	public List<Student> findByNameLike(String name);
	
}
