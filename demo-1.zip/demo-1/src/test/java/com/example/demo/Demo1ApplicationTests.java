package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1ApplicationTests {
	
@Autowired
StudentDAO stu;
@Test
public void sample()
{
	Student s=new Student(2,"Navi","10");
	stu.save(s);
	Student s1=stu.findByName("Navi");
	System.out.println(s1);
	List<Student> sl=stu.findallname("10");
	System.out.println(sl);
	List<Student> sln=stu.findByNameLike("av");
	System.out.println(sln);
}
	
	
	
	@Test
	void contextLoads() {
	}
}
