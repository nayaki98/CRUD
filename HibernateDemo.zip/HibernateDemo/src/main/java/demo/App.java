package demo;

import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class App {
  public static void main(String[] args) {
	  StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
	  
	SessionFactory factory = meta.getSessionFactoryBuilder().build();  
	Session session = factory.openSession();  
	Transaction t = session.beginTransaction(); 
	Address ad=new Address(6,"East","erode");
	session.persist(ad);
	t.commit();
	
	Query query=session.getNamedQuery("selectquery");
	query.setParameter("city", "erode");
	query.setParameter("doorno",8);
	List<Address> el=query.getResultList();
	Iterator<Address> itr=el.iterator();
	while(itr.hasNext())
	{
		Address a=itr.next();
		System.out.println(a);
	}
	System.out.println(el);
	factory.close();
	session.close();
  }
}
