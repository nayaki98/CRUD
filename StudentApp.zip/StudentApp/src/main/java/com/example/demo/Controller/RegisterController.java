package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Registration;
import com.example.demo.repo.RegisterRepo;

@RestController
@CrossOrigin("http://localhost:4200/")
public class RegisterController {

	@Autowired
	RegisterRepo resrepo;
	
	
	Registration reg =new Registration();
	
	static Integer count = 0;
	public String generateID(String name)
	{
		
		String uname = name.substring(0, 3);
	    String countstr = count.toString().length() == 1 ? ("00" + count)
	            : count.toString().length() == 2 ? ("0" + count) : count.toString();
	    count = count + 1;
	    String sid = uname + countstr+count;
	    return sid;
	}
	@PostMapping("/registerstudent")
	public String registerStudent(@RequestBody Registration resgister)
	{
		String name= resgister.getStudentName();
		resgister.setStudentId(generateID(name));
		resrepo.save(resgister);
		//return getAllUser();
		return "Hi " + resgister.getStudentName() + " your details get registered to database and your ID is " + resgister.getStudentId();
	}
	
	@GetMapping("/getstudentlist")
	public List<Registration> getAllUser()
	{
		
		return resrepo.findAll();
	}
}
