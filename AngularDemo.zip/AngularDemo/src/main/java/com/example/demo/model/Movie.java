package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Movie {
	@Id
	@GeneratedValue
	public int movieid;
	public String title;
	public String description;
	public Date releasedate;
	
	
	public Movie(int movieid, String title, String description, Date releasedate) {
		super();
		this.movieid = movieid;
		this.title = title;
		this.description = description;
		this.releasedate = releasedate;
	}


	public int getMovieid() {
		return movieid;
	}


	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getReleasedate() {
		return releasedate;
	}


	public void setReleasedate(Date releasedate) {
		this.releasedate = releasedate;
	}


	public Movie() {
		super();
	}

}
