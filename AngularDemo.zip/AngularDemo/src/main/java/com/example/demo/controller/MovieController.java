package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Movie;
import com.example.demo.repo.MovieRepo;

@CrossOrigin("http://localhost:4200")
@RestController
public class MovieController {
	@Autowired
	MovieRepo movierepo;
	
	
	@GetMapping("/movielist")
	public List<Movie> findall()
	{
		return movierepo.findAll();
	}
	
	@GetMapping("/movie/{movieid}")
	public Optional<Movie> findbyid(@PathVariable int movieid)
	{
		return movierepo.findById(movieid);
	}
	

}
