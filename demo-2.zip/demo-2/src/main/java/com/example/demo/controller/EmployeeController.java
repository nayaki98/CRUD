package com.example.demo.controller;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeController {

	
	public String save(Employee e);
	public List<Employee> getEmp();
}
