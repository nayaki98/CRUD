package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeDao;
import com.example.demo.model.Employee;

@Service
public class EmployeServiceImpl implements EmployeService{

	@Autowired
	EmployeDao empdao;

	
	public String save(Employee e) {
		empdao.save(null);
		return "Saved";
	}


	@Override
	public List<Employee> getemp() {
		
		return (List<Employee>) empdao.findAll();
	}
	
	
}
