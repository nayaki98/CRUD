package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empno;
	
	private int salary;
	
	private String city;

	private String empName;
	
	

	public Employee() {
		super();
	}



	public Employee(int empno, int salary, String city, String empName) {
		super();
		this.empno = empno;
		this.salary = salary;
		this.city = city;
		this.empName = empName;
	}

	


	public Employee(int salary, String city, String empName) {
		super();
		this.salary = salary;
		this.city = city;
		this.empName = empName;
	}



	public int getEmpno() {
		return empno;
	}



	public void setEmpno(int empno) {
		this.empno = empno;
	}



	public int getSalary() {
		return salary;
	}



	public void setSalary(int salary) {
		this.salary = salary;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", salary=" + salary + ", city=" + city + ", empName=" + empName + "]";
	}
	
	
}
