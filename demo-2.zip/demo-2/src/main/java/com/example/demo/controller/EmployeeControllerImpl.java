package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeService;

@RestController
public class EmployeeControllerImpl implements EmployeeController{

	@Autowired
	EmployeService empservice;
	
	@GetMapping("/sample")
	public String sam()
	{
		
		System.out.println("Hitted....!");
		return "hello";
	}

	@PostMapping("/saveemp")
	public String save(@RequestBody Employee e) {

		/*
		 * Employee emp=new Employee(); emp.setEmpno(e.getEmpno());
		 * emp.setSalary(e.getSalary()); emp.setEmpName(e.getEmpName());
		 * emp.setCity(e.getCity());
		 */
		return empservice.save(e);
	}
	
	@GetMapping("/emplist")
	public List<Employee> getEmp()
	{
		return empservice.getemp();
	}

	
}
